[リソースパックについて]
- Fabric専用です。
- 11段用として製作しています。
- 他のテクスチャと併用しても問題ありません。
- オーバーワールド用に高さを設定してあります。
- 好みの高さに変えたい場合は中のa.propertiesファイルのheightsを自分で変えてください。

[導入]
- 本zipファイルをresourcepacksディレクトリ内に配置してください。
- Continuity(https://modrinth.com/mod/continuity/version/2.0.1+1.18.2)、もしくは他のCTMテクスチャを使用できるようにするMODが必要です。
- Sodiumを使用する場合Indium(https://modrinth.com/mod/indium/version/1.0.7+mc1.18.2)も必要になります。

[ライセンス]
- MITライセンスに基づきます。
- 詳細はLICENSE.txtを参照してください。

[サポート]
KirisameKeiのdiscordサーバ(https://discord.gg/nrvMKBT)にて行います。

[制作環境]
fabric-loader-0.16.14-1.18.2

[更新履歴]
2022.01.12 Kuriがver1.12.2用に作成
2025.05.05 KirisameKeiがver1.18.2用に更新